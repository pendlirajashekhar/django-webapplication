from django.contrib import admin
from.models import TrainerAddDetails
from.models import TrainerCredits
from.models import TrainerRegistration

# Register your models here.
admin.site.register(TrainerAddDetails)
admin.site.register(TrainerCredits)
admin.site.register(TrainerRegistration)

